---
title: "How to Convert Between Wealth and Income Tax"
slug: winc
date: "May 2026"
url: "https://www.paulgraham.com/winc.html"
word_count: 515
reading_time_min: 3
---

# How to Convert Between Wealth and Income Tax

_May 2026 · 515 words · 3 min read · [original](https://www.paulgraham.com/winc.html)_

How do you convert between wealth and income tax? If a government imposes a wealth tax of 1%, what's the equivalent in income tax?

It's clear from the way most politicians talk about the subject that they not only don't know the answer, but don't even realize there's such a question.

In fact the conversion rate between them is about 20. A wealth tax of 1% is equivalent to an income tax of 20%.

To convert between wealth and income tax rates, you have to divide by the rate of return on capital. The conversion rate of 20 comes from assuming that the risk-free rate of return is 5%. Historically that's an optimistic assumption. 4% might be more realistic. But 5% will do. [1]

If we run through an example it will be clear how this works. Suppose you have $100, you're getting a 5% rate of return on this capital, and there's a 20% income tax. The 5% rate of return means at the end of one year your $100 has made you another $5. But you have to pay 20% of that, or $1, in income tax, so your after-tax income is $4. At the end of the year, after paying taxes, you have $100 + $4 = $104.

Now suppose instead of a 20% income tax, there's a 1% wealth tax. At the end of the year your $100 has made you another $5, as before. But that year you had to pay 1% of your $100, or $1, in wealth tax. So at the end of the year you have $99 + $5 = $104.

Each 1% of wealth tax is equivalent to 20% of income tax.

It's clear that politicians don't get this from the way they talk about a "mere 1%" wealth tax. None of them would speak of adding a "mere 20%" to the income tax rate, even though that's mathematically the same thing. [2]

Politicians understand that an additional 20% income tax would be a lot. And indeed a US state that added 20% to its top income tax rate would have extraordinarily high taxes.

Currently the country with the highest marginal income tax rate is Denmark, at 60.5%. The top US federal tax rate is 37%, and the median state income tax rate is Oklahoma's, which is 4.75%. So in the median case, a state adding an additional 20% in income tax would have a total marginal tax rate of 37% + 4.75% + 20%, or 61.75%. [3]

In the median case, US state politicians talking about adding a "mere 1%" wealth tax are talking about causing the residents of their state to have the highest taxes in the world. That's not the sort of decision you make lightly.

That's why I think few politicians currently understand how to convert between wealth and income taxes. You can tell from the way they talk about the subject that they don't understand the momentousness of what they're proposing. But I'm optimistic that we can teach them. The answer's not hard to understand, once you realize the question exists.

## Notes

- **[1]** It's possible to get a higher rate of return if you're willing to risk losing your capital. But to convert between tax rates you should use the risk-free rate of return, because considered as an anti-investment, a wealth tax is absolutely risk-free: you will absolutely owe the government that money. And while you do have to put "risk-free" in scare quotes when talking about returns, the kind of risks you're talking about now are the almost apocalyptic kind that would make tax rates a moot point.
- **[2]** The same conversion rate applies to capital gains. The source of the multiple is whether the money is taxed every year or just once. Indeed it's the same math you'd use to calculate the value of any income-generating asset.
- **[3]** You can deduct some state tax from your federal income taxes, but there's a cap on how much you can deduct, which means in the marginal case we simply add the two rates.

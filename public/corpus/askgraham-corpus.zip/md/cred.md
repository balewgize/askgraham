---
title: "Coronavirus and Credibility"
slug: cred
date: "April 2020"
url: "https://www.paulgraham.com/cred.html"
word_count: 235
reading_time_min: 2
---

# Coronavirus and Credibility

_April 2020 · 235 words · 2 min read · [original](https://www.paulgraham.com/cred.html)_

I recently saw a video of TV journalists and politicians confidently saying that the coronavirus would be no worse than the flu. What struck me about it was not just how mistaken they seemed, but how daring. How could they feel safe saying such things?

The answer, I realized, is that they didn't think they could get caught. They didn't realize there was any danger in making false predictions. These people constantly make false predictions, and get away with it, because the things they make predictions about either have mushy enough outcomes that they can bluster their way out of trouble, or happen so far in the future that few remember what they said.

An epidemic is different. It falsifies your predictions rapidly and unequivocally.

But epidemics are rare enough that these people clearly didn't realize this was even a possibility. Instead they just continued to use their ordinary m.o., which, as the epidemic has made clear, is to talk confidently about things they don't understand.

An event like this is thus a uniquely powerful way of taking people's measure. As Warren Buffett said, "It's only when the tide goes out that you learn who's been swimming naked." And the tide has just gone out like never before.

Now that we've seen the results, let's remember what we saw, because this is the most accurate test of credibility we're ever likely to have. I hope.

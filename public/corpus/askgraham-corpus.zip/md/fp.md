---
title: "Fashionable Problems"
slug: fp
date: "December 2019"
url: "https://www.paulgraham.com/fp.html"
word_count: 188
reading_time_min: 1
---

# Fashionable Problems

_December 2019 · 188 words · 1 min read · [original](https://www.paulgraham.com/fp.html)_

I've seen the same pattern in many different fields: even though lots of people have worked hard in the field, only a small fraction of the space of possibilities has been explored, because they've all worked on similar things.

Even the smartest, most imaginative people are surprisingly conservative when deciding what to work on. People who would never dream of being fashionable in any other way get sucked into working on fashionable problems.

If you want to try working on unfashionable problems, one of the best places to look is in fields that people think have already been fully explored: essays, Lisp, venture funding  you may notice a pattern here. If you can find a new approach into a big but apparently played out field, the value of whatever you discover will be multiplied by its enormous surface area.

The best protection against getting drawn into working on the same things as everyone else may be to genuinely love what you're doing. Then you'll continue to work on it even if you make the same mistake as other people and think that it's too marginal to matter.

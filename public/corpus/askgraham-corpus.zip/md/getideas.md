---
title: "How to Get New Ideas"
slug: getideas
date: "January 2023"
url: "https://www.paulgraham.com/getideas.html"
word_count: 145
reading_time_min: 1
---

# How to Get New Ideas

_January 2023 · 145 words · 1 min read · [original](https://www.paulgraham.com/getideas.html)_

(Someone fed my essays into GPT to make something that could answer questions based on them, then asked it where good ideas come from. The answer was ok, but not what I would have said. This is what I would have said.)

The way to get new ideas is to notice anomalies: what seems strange, or missing, or broken? You can see anomalies in everyday life (much of standup comedy is based on this), but the best place to look for them is at the frontiers of knowledge.

Knowledge grows fractally. From a distance its edges look smooth, but when you learn enough to get close to one, you'll notice it's full of gaps. These gaps will seem obvious; it will seem inexplicable that no one has tried x or wondered about y. In the best case, exploring such gaps yields whole new fractal buds.
